class StitchingError(Exception):
    pass


class StitchingWarning(UserWarning):
    pass
